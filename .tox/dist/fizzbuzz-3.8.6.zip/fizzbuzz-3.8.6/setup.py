# -*- coding: utf-8 -*-
from setuptools import setup, find_packages

setup(
    name='fizzbuzz',
    version='3.8.6',
    url='https://github.com/vous/fizzbuzz.git',
    author='Vous',
    author_email='vous@etu.unistra.fr',
    description='Réalisation du TP 02',
    packages=find_packages(),
)
